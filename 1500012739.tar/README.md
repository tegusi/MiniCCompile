## MiniC

The project of *Practice for Compiler Design* in PKU. The schedule is listed below:

- [x] MiniC -> Eeyore 
- [x] Eeyore -> Tigger
- [x] Tigger -> RiscV 

## File

- minic2eeyore
	
	Source code of minic2eeyore:
	- **global.h** Declaration of each variable
	- **util.c** Helper functions
	- **minic.y** yacc file
	- **minic.l** lex file
	
- eeyore2tigger
- tigger2riscv
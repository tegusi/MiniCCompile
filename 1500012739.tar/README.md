##MiniC

The project of *Practice for Compiler Design* in PKU. The schedule is listed below:

- [x] MiniC -> Eeyore 
- [x] Eeyore -> Tigger
- [x] Tigger -> RiscV 
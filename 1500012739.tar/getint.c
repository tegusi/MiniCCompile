#include <stdio.h>
int getint() {
  int q;
  scanf("%d", &q);
  return q;
}

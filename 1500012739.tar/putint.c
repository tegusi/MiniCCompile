#include <stdio.h>
int putint(int x) {
  printf("%d", x);
}

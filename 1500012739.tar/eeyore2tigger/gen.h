// void assign(string a,string b);
void gen();
